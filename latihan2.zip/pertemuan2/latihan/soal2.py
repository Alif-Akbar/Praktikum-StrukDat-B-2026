mahasiswa = ("A001", "Budi", "Informatika")

print("Nama:", mahasiswa[1]) # Menampilkan nama mahasiswa
for info in mahasiswa:
    print(info) # Menampilkan semua informasi dalam tuple

# tuple bersifat immutable
